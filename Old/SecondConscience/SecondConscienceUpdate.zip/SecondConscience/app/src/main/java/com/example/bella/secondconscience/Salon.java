package com.example.bella.secondconscience;

/**
 * Created by Alecia on 4/24/2017.
 */

public class Salon {
    //creates getter and setter for the string name
    String name;
    String mess;

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
    public void setMessage(String mess) {
        this.mess = mess;
    }

    public String getMessage() {
        return mess;
    }

}
